from django.shortcuts import render
from projects.models import Biblioteca

def project_index(request):
    projects = Biblioteca.objects.all()
    context = {
        'projects': projects
    }
    return render(request, 'project_index.html', context)
	
def project_detail(request, pk):
    project = Biblioteca.objects.get(pk=pk)
    context = {
        'project': project
    }
    return render(request, 'project_detail.html', context)